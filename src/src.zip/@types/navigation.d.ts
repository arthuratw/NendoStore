export declare global {
    namespace ReactNavigation {
        interface RootParamList {
            Profile: undefined;
            Login: undefined;
            View: undefined;
            Cart: undefined;
            Payment: undefined;
        }
    }
}