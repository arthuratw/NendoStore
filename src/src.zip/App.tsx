/* eslint-disable prettier/prettier */

import { SafeAreaView } from 'react-native';
import Login from './modules/login';
import { Routes } from './routes';




const App = () => {
  return <Routes />
};

export default App;
