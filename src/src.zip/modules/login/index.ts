/* eslint-disable prettier/prettier */
import Login from './screens/Login';

export default Login;
