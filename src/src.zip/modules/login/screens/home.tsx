import { View, Text } from "react-native";

export function home() {

    return (
        <View>
            <Text>jjjjjjjjjj</Text>
        </View>
    );
}