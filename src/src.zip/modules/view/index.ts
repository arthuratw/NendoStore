import ViewItens from './screens/View'

export default ViewItens;